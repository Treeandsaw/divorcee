<?php
// E-mail 수정시 인증 메일 (회원님께 발송)
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

@include($misc_skin_path.'/register_form_update_mail3.php');

?>