<?php
include_once('./_common.php');
include_once(G5_CAPTCHA_PATH.'/captcha.lib.php');

$po = sql_fetch(" select * from {$g5['poll_table']} where po_id = '{$po_id}' ");
if (!$po['po_id'])
    alert('설문조사 정보가 없습니다.');

if ($member['mb_level'] < $po['po_level'])
    alert('권한 '.$po['po_level'].' 이상의 회원만 결과를 보실 수 있습니다.');

$g5['title'] = '설문조사 결과';

$po_subject = $po['po_subject'];

$max = 1;
$total_po_cnt = 0;
for ($i=1; $i<=9; $i++) {
    $poll = $po['po_poll'.$i];
    if ($poll == '') break;

    $count = $po['po_cnt'.$i];
    $total_po_cnt += $count;

    if ($count > $max)
        $max = $count;
}
$nf_total_po_cnt = number_format($total_po_cnt);

$list = array();

for ($i=1; $i<=9; $i++) {
    $poll = $po['po_poll'.$i];
    if ($poll == '') { break; }

    $list[$i]['content'] = $poll;
    $list[$i]['cnt'] = $po['po_cnt'.$i];
    if ($total_po_cnt > 0)
        $list[$i]['rate'] = ($list[$i]['cnt'] / $total_po_cnt) * 100;

    $bar = (int)($list[$i]['cnt'] / $max * 100);

    $list[$i]['bar'] = $bar;
    $list[$i]['num'] = $i;
}

$list2 = array();

// 기타의견 리스트
$sql = " select a.*, b.mb_open, b.as_level
           from {$g5['poll_etc_table']} a
           left join {$g5['member_table']} b on (a.mb_id = b.mb_id)
          where po_id = '{$po_id}' order by pc_id desc ";
$result = sql_query($sql);
for ($i=0; $row=sql_fetch_array($result); $i++) {
    $list2[$i]['pc_name']  = get_text($row['pc_name']);
	$list2[$i]['photo']	   = apms_photo_url($row['mb_id']);
	$list2[$i]['name']     = apms_sideview($row['mb_id'], get_text(cut_str($row['pc_name'],10)), '', '', $row['as_level']);
    $list2[$i]['idea']     = get_text(cut_str($row['pc_idea'], 255));
    $list2[$i]['datetime'] = $row['pc_datetime'];

    $list2[$i]['del'] = '';
    if ($is_admin == 'super' || ($row['mb_id'] == $member['mb_id'] && $row['mb_id']))
        $list2[$i]['del'] = '<a href="'.G5_BBS_URL.'/poll_etc_update.php?w=d&amp;pc_id='.$row['pc_id'].'&amp;po_id='.$po_id.'&amp;skin_dir='.$skin_dir.'" class="poll_delete">';
}

// 기타의견 입력
$is_etc = false;
if ($po['po_etc']) {
    $is_etc = true;
    $po_etc = $po['po_etc'];
    if ($member['mb_id'])
        $name = '<b>'.$member['mb_nick'].'</b> <input type="hidden" name="pc_name" value="'.$member['mb_nick'].'">';
    else
        $name = '<input type="text" name="pc_name" size="10" class="input" required>';
}

$list3 = array();

// 다른투표
$sql = " select po_id, po_subject, po_date from {$g5['poll_table']} where po_id <> '{$po_id}' order by po_id desc ";
$result = sql_query($sql);
for ($i=0; $row2=sql_fetch_array($result); $i++) {
    $list3[$i]['po_id'] = $row2['po_id'];
    $list3[$i]['date'] = substr($row2['po_date'],2,8);
    $list3[$i]['subject'] = cut_str($row2['po_subject'],60,"…");
}

$is_etc_poll = ($i) ? true : false;

// Page ID
$pid = ($pid) ? $pid : '';
$at = apms_page_thema($pid);
include_once(G5_LIB_PATH.'/apms.thema.lib.php');

if(!$skin_dir) $skin_dir = 'basic';

if(USE_G5_THEME) {
	if(preg_match('#^theme/(.+)$#', $skin_dir, $match)) {
		if (G5_IS_MOBILE) {
			$poll_skin_path = G5_THEME_MOBILE_PATH.'/'.G5_SKIN_DIR.'/poll/'.$match[1];
			if(!is_dir($poll_skin_path))
				$poll_skin_path = G5_THEME_PATH.'/'.G5_SKIN_DIR.'/poll/'.$match[1];
			$poll_skin_url = str_replace(G5_PATH, G5_URL, $poll_skin_path);
		} else {
			$poll_skin_path = G5_THEME_PATH.'/'.G5_SKIN_DIR.'/poll/'.$match[1];
			$poll_skin_url = str_replace(G5_PATH, G5_URL, $poll_skin_path);
		}
		//$skin_dir = $match[1];
	} else {
		if (G5_IS_MOBILE) {
			$poll_skin_path = G5_MOBILE_PATH.'/'.G5_SKIN_DIR.'/poll/'.$skin_dir;
			$poll_skin_url  = G5_MOBILE_URL.'/'.G5_SKIN_DIR.'/poll/'.$skin_dir;
		} else {
			$poll_skin_path = G5_SKIN_PATH.'/poll/'.$skin_dir;
			$poll_skin_url  = G5_SKIN_URL.'/poll/'.$skin_dir;
		}
	}
} else {
	if(is_dir(THEMA_PATH.'/widget/'.$skin_dir)) {
		$poll_skin_path = THEMA_PATH.'/widget/'.$skin_dir;
		$poll_skin_url  = THEMA_URL.'/widget/'.$skin_dir;
	} else {
		$poll_skin_path = G5_SKIN_PATH.'/poll/'.$skin_dir;
		$poll_skin_url  = G5_SKIN_URL.'/poll/'.$skin_dir;
	}

	// 스킨 체크
	list($poll_skin_path, $poll_skin_url) = apms_skin_thema('poll', $poll_skin_path, $poll_skin_url); 
}

// 설정값 불러오기
$is_poll_sub = true;
@include_once($poll_skin_path.'/config.skin.php');

if($is_poll_sub) {
	include_once(G5_PATH.'/head.sub.php');
	if(!USE_G5_THEME) @include_once(THEMA_PATH.'/head.sub.php');
} else {
	include_once('./_head.php');
}

$widget_path = $skin_path = $poll_skin_path;
$widget_url = $skin_url = $poll_skin_url;

include_once ($skin_path.'/poll_result.skin.php');

if($is_poll_sub) {
	if(!USE_G5_THEME) @include_once(THEMA_PATH.'/tail.sub.php');
	include_once(G5_PATH.'/tail.sub.php');
} else {
	include_once('./_tail.php');
}
?>
