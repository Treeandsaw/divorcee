<?php
include_once('./_common.php');
echo apms_colorset_skin($t_id, $c_id, '', $opt, $size);
?>