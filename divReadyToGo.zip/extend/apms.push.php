<?php
if (!defined('_GNUBOARD_')) exit;

// 1.7.4 이상버전부터는 필요없기 때문에 이 파일을 삭제해 주세요.

?>