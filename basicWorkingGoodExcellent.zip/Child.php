	<div id='Child'>
		<div class="col-sm-12 masthead">  

 			<div class="form-group">  
				<div class="col-sm-12" style="text-align: center; padding: 20px;"> 
 					<div class="alert alert-success" role="alert">Child Info</div>
				</div> 
			</div>  

			<div class="form-group">
				<label class="col-sm-3 control-label" for="qa_36">First Middle Last Name</label>
				<div class="col-sm-9"> 
					Are there any minor children?	Yes No
				</div>
			</div>

			<div class="form-group">
				<label class="col-sm-3 control-label" for="qa_37">First Middle Last Name</label>
				<div class="col-sm-9"> 
					Are there any minor children?	Yes No
				</div>
			</div>

			<div class="form-group debt">
				<div class="col-sm-3 debt"> 
						First Middle Last
				</div>
				<div class="col-sm-3 debt"> 
						Date of Birth
				</div>
				<div class="col-sm-3 debt"> 
						Social Security Number
				</div>
				<div class="col-sm-3 debt"> 
						Custodial Parent <br> (Husband, Wife or Both)
				</div> 
			</div>

		<div class="form-group"> 
			<div class="col-sm-3"> 
					<input type="text" name="qa_32" value="<?php echo get_text($write['qa_32']); ?>" id="qa_32" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_33" value="<?php echo get_text($write['qa_33']); ?>" id="qa_33" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_34" value="<?php echo get_text($write['qa_34']); ?>" id="qa_34" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_35" value="<?php echo get_text($write['qa_35']); ?>" id="qa_35" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
		</div>

		<div class="form-group"> 
			<div class="col-sm-3"> 
					<input type="text" name="qa_38" value="<?php echo get_text($write['qa_38']); ?>" id="qa_38" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_39" value="<?php echo get_text($write['qa_39']); ?>" id="qa_39" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_40" value="<?php echo get_text($write['qa_40']); ?>" id="qa_40" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_41" value="<?php echo get_text($write['qa_41']); ?>" id="qa_41" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
		</div>

		<div class="form-group"> 
			<div class="col-sm-3"> 
					<input type="text" name="qa_42" value="<?php echo get_text($write['qa_42']); ?>" id="qa_42" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_43" value="<?php echo get_text($write['qa_43']); ?>" id="qa_43" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_44" value="<?php echo get_text($write['qa_44']); ?>" id="qa_44" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_45" value="<?php echo get_text($write['qa_45']); ?>" id="qa_45" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
		</div>

		<div class="form-group"> 
			<div class="col-sm-3"> 
					<input type="text" name="qa_46" value="<?php echo get_text($write['qa_46']); ?>" id="qa_46" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_47" value="<?php echo get_text($write['qa_47']); ?>" id="qa_47" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_48" value="<?php echo get_text($write['qa_48']); ?>" id="qa_48" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
			<div class="col-sm-3"> 
					<input type="text" name="qa_49" value="<?php echo get_text($write['qa_49']); ?>" id="qa_49" class="form-control input-sm" size="50" maxlength="255">
					<input type="hidden" name="qa_html" value="1"> 
			</div>
		</div>

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Child support is already being enforced through the County District Attorney's Office under Case No. 
					in the amount of $  and will continue to be handled by that office. 
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Will you be requesting Child Support Enforcement services from the District Attorney?   Yes   No
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Who will be providing transportation for visitation?   Wife     Husband     Both equally
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Who is responsible for child(ren)'s health insurance?   Wife   Husband  
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Payment for child(ren)'s health insurance provided by:	 Military     Employer     State Subsidy  
 None     Other  
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-12"> 
					How much will Wife/Husband pay for health insurance per month? $  
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Does this case involve family violence?   Yes   No
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Income Tax - Who is to claim the child/ren as dependants on the income tax return? If you are alternating years please specify who will have odd and even years.
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-4"> 
					Wife   Husband   Other, please specify:
				</div> 
				<div class="col-sm-8"> 
					<textarea name="eee" id="" cols="85" rows="3"></textarea>
				</div> 
			</div>  

			<div class="form-group"> 
				<div class="col-sm-12"> 
					<b>Only complete A. & B. below if this is a Complaint for Divorce</b>
						A. List who the children have lived with, and all addresses of children for the last 5 years with dates at each address including current address:
				</div>
			</div>

			<div class="form-group debt">
				<div class="col-sm-3 debt"> 
					Wife/Husband
				</div>
				<div class="col-sm-3 debt"> 
					Address
				</div>
				<div class="col-sm-3 debt"> 
					From
				</div>
				<div class="col-sm-3 debt"> 
					To
				</div> 
			</div>

			<div class="form-group"> 
				<div class="col-sm-3"> 
						<input type="text" name="qa_50" value="<?php echo get_text($write['qa_50']); ?>" id="qa_50" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_51" value="<?php echo get_text($write['qa_51']); ?>" id="qa_51" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_52" value="<?php echo get_text($write['qa_52']); ?>" id="qa_52" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_53" value="<?php echo get_text($write['qa_53']); ?>" id="qa_53" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
			</div>

			<div class="form-group"> 
				<div class="col-sm-3"> 
						<input type="text" name="qa_54" value="<?php echo get_text($write['qa_54']); ?>" id="qa_54" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_55" value="<?php echo get_text($write['qa_55']); ?>" id="qa_55" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_56" value="<?php echo get_text($write['qa_56']); ?>" id="qa_56" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_57" value="<?php echo get_text($write['qa_57']); ?>" id="qa_57" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
			</div>

			<div class="form-group"> 
				<div class="col-sm-3"> 
						<input type="text" name="qa_58" value="<?php echo get_text($write['qa_58']); ?>" id="qa_58" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_59" value="<?php echo get_text($write['qa_59']); ?>" id="qa_59" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_60" value="<?php echo get_text($write['qa_60']); ?>" id="qa_60" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
				<div class="col-sm-3"> 
						<input type="text" name="qa_61" value="<?php echo get_text($write['qa_61']); ?>" id="qa_61" class="form-control input-sm" size="50" maxlength="255">
						<input type="hidden" name="qa_html" value="1"> 
				</div>
			</div>   

			<div class="form-group"> 
				<div class="col-sm-12"> 
					B. List children's visitation/contact with each parent for the last six months
				</div>
			</div>     

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Husband    	 Lives with  Visitation  Other 
				</div>
			</div>     

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Wife    	 Lives with  Visitation  Other 
				</div>
			</div>

			<div class="form-group debt">
				<div class="col-sm-12 debt"> 
					 Child Custody - Click for child custody definitions
				</div> 
			</div>     

			<div class="form-group"> 
				<div class="col-sm-12"> 
					<b>Legal Custody: </b>Decision making pertaining to the welfare of child/children. Legal custody usually deals with issues involving the child's financial care, education, religion and health. Joint legal is the most common.
					<br><br>
 					Joint                 Wife                 Husband
				</div>
			</div>     

			<div class="form-group"> 
				<div class="col-sm-12"> 
					If this is not joint please list the reason why one party would have sole legal custody: <br>
					<input type="text">
				</div>
			</div>     

			<div class="form-group"> 
				<div class="col-sm-12"> 
					Physical Custody: Who the child lives with and the other party having visitation rights.
 Joint                 Wife                 Husband
				</div>
			</div>

			<div class="form-group debt">
				<div class="col-sm-12 debt"> 
					 Child Support - Click for child support guidelines
				</div> 
			</div>  

			<div class="form-group">  
				<div class="col-sm-12"> 
					<div class="alert alert-info" role="alert">
						<h5 class='paddingLine'>
							The child support listed below is consistent with the appropriate formula set forth in paragraph (b) of subsection (1) of NRS 125B.070 and 125B.080, or an appropriate deviation must be described below. If someone is unemployed the statutes require $100 minimum per child per month.
						</h5>
					</div>
				</div> 
			</div>    

			<div class="form-group">
				<div class="col-sm-8"> 
					 Husband's gross monthly income: (do not use commas)
				</div> 
				<div class="col-sm-4"> 
					 <input type="text">
				</div> 
			</div>      

			<div class="form-group">
				<div class="col-sm-8"> 
					 Wife's gross monthly income: (do not use commas)
				</div> 
				<div class="col-sm-4"> 
					 <input type="text">
				</div> 
			</div>        

			<div class="form-group">
				<div class="col-sm-8"> 
					 Is the support to be withheld from employer?    Yes   No
				</div> 
				<div class="col-sm-4"> 
					 <input type="text">
				</div> 
			</div>   

			<div class="form-group debt">
				<div class="col-sm-12 debt"> 
					 Child Support - Click for child support guidelines
				</div> 
			</div>  

			<div class="form-group">  
				<div class="col-sm-12"> 
					<div class="alert alert-info" role="alert">
						<h5 class='paddingLine'>
							<b>Required Visitation/Custody Schedule:</b> Choose from the following examples for the non-custodial parent's visitation with the minor child(ren) or use the "Joint Custody or Other" box. Each must be specific as to days, dates and times. If you select joint physical custody you must only list each parties' custody schedule in the "Other" section below and it must be roughly equal. Please include holiday and vacation times.
						</h5>
					</div>
				</div> 
			</div>     

			<div class="form-group">
				<div class="col-sm-12"> 
				 	Beginning with the second weekend following the signing of the Decree of Divorce and continuing thereafter every other weekend beginning on Friday at 6:00 p.m. until Sunday at 8:00 p.m.;
				</div> 
			</div>     

			<div class="form-group">
				<div class="col-sm-12"> 
					For holidays on even numbered years from 8:00 a.m. until 8:00 p.m. on Christmas Eve, Thanksgiving,	
				</div> 
			</div>     

			<div class="form-group">
				<div class="col-sm-12"> 
					 For the child(ren)'s birthday(s) on even numbered years from 8:00 a.m. until 8:00 p.m.;
				</div> 
			</div>       

			<div class="form-group">
				<div class="col-sm-12"> 
					 Each year the non-custodial parent will be entitled to one (1) week uninterruped vacation with the child(ren) beginning at 8:00 a.m. on    , and continuing until 8:00 p.m. on    ;
				</div> 
			</div>       

			<div class="form-group">
				<div class="col-sm-12"> 
					During every summer vacation the non-custodial parent shall have physical custody of the parties' minor child(ren) beginning at 8:00 a.m. on    , and continuing until 8:00 p.m. on 
				</div> 
			</div>       

			<div class="form-group">
				<div class="col-sm-12"> 
					 Joint Custody or Other (you must include all days, dates and times)
				</div> 
			</div>       

			<div class="form-group">
				<div class="col-sm-12"> 
					 <textarea name="" id="" cols="134" rows="3"></textarea>
				</div> 
			</div>    

			<div class="form-group"> 
				<div class="col-sm-12" style="text-align: center;"> 
					<br><br>
					<button type="submit" id="btn_submit" accesskey="s" class="btn btn-color btn-sm">
						<i class="fa fa-check"></i> <b>작성완료</b>
					</button> 
					<br><br><br><br>
				</div>
			</div> 
			
		</div>
		<div class="col-sm-4"></div>		
	</div> 