<div id='Payment'>
	<div class="col-sm-12">

		<div class="form-group">  
			<div class="col-sm-12">   
				<div class="alert alert-success" role="alert">Payment</div> 
			</div> 
		</div> 

		<div class="form-group">  
			<div class="col-sm-12"> 
				<div class="alert alert-info" role="alert">
					<h5 class='paddingLineCenter'>
						 It has not been set yet.
					</h5>
				</div>
			</div> 
		</div>
  
 
		
	</div> 	
</div> 